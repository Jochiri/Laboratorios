print("20/03/2024")
print("José Andrés Lemus Otzoy - 1108624")
print("ACTIVIDAD NO. 03 - SEMANA 10")
#
print()
print()
print("Ingrese su fecha de nacimiento en números: ")
dob= int(input("Dia: "))
mob= int(input("Mes: "))
yob= int(input("Año: "))
while dob>31 or dob<1 or mob<1 or mob>12:
    print("Error: Escriba una fecha válida. Intentelo de nuevo")
    dob= int(input("Dia: "))
    mob= int(input("Mes: "))
    yob= int(input("Año: "))
print()
match(mob):
        case 1:
            if dob>=20:
                print("Usted es un Acuario")
            else:
                print("Usted es un Capricornio")
        case 2:
            if dob>=19:
                print("Usted es un Piscis")
            else:
                print("Usted es un Acuario")
        case 3:
            if dob>=21:
                print("Usted es un Aries")
            else:
                print("Usted es un Piscis")
        case 4:
            if dob>=20:
                print("Usted es un Tauro")
            else:
                print("Usted es un Aries")
        case 5:
            if dob>=21:
                print("Usted es un Géminis")
            else: 
                print("Usted es un Tauro")
        case 6: 
            if dob>=21:
                print("Usted es un Cancer")
            else:
                print("Usted es un Géminis")
        case 7:
            if dob>=23:
                print("Usted es un Leo")
            else: 
                print("Usted es un Cancer")
        case 8:
            if dob>=23:
                print("Usted es un Virgo")
            else:
                print("Usted es un Leo")
        case 9:
            if dob>=23:
                print("Usted es un Libra")
            else:
                print("Usted es un Virgo")
        case 10:
            if dob>=23:
                print("Usted es un Escorpio")
            else:
                print("Usted es un Libra")
        case 11:
            if dob>=22:
                print("Usted es un Sagitario")
            else:
                print("Usted es un Escorpio")
        case 12:
            if dob>=22:
                print("Usted es un Capricornio")
            else: 
                print("Usted es un Sagitario")
    



