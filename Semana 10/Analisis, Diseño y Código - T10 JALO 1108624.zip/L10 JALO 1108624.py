print("Semana No. 10: Ejercicio 1")
nmes=int(input("Ingresa el número de mes "))
if 1>nmes or nmes>12:
    print("Error: El número a ingresar debe estar contenido entre 1 y 12")
else:
    match(nmes):
        case 1:
            print("MES: enero")
        case 2:
            print("MES: Febrero")
        case 3:
            print("MES: Marzo")
        case 4:
            print("MES: Abril")
        case 5:
            print("MES: Mayo")
        case 6: 
            print ("MES: Junio")
        case 7:
            print("MES: Julio")
        case 8:
            print("MES: Agosto")
        case 9:
            print("MES: Septiembre")
        case 10:
            print("MES: Octubre")
        case 11:
            print("MES: Noviembre")
        case 12:
            print("MES: Diciembre)")

print("Semana 10: Ejercicio 2")
A=int(input("Indique un numero mayor que cero "))   
B=int(input("Indique un segundo numero mayor que cero "))
C=int(input("Indique un tercer numero mayor que cero "))
if A>B:
    if A> C:
        print("El mayor es ", A)
    else:
        if A==C:
            print ("Los mayores son", A, "y", C)
        else: 
            print ("El mayor es", C)
else:
    if A==B:
        if A>C:
            print("Su número mayor es: ", A, "y", B)
        else:
            if A == C:
                print("Sus numeros mayores son: ", A, "y", B,"y",C)
            else:
                print("Su numero mayor es:", C)
    else:
        if B>C:
            print("Su numero mayor es", B)
        else:
            if B==C:
                print("Sus numeros mayores son", B, "y", C)
            else:
                print("Su numero mayor es: ", C)
            

        

    